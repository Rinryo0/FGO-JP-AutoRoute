import copy
import json
import os
import sys
import threading
from pathlib import Path

LOCK = threading.RLock()
# In a PyInstaller one-file build, bundled resources are read-only and are
# extracted to sys._MEIPASS. Keep editable settings/templates in LocalAppData.
RESOURCE_ROOT = Path(getattr(sys, '_MEIPASS', Path(__file__).resolve().parent.parent))
if getattr(sys, 'frozen', False):
    _user_root = os.environ.get('LOCALAPPDATA') or os.environ.get('APPDATA') or str(Path.home())
    ROOT = Path(_user_root) / 'FGO-JP-AutoRoute'
else:
    ROOT = Path(__file__).resolve().parent.parent
CONFIG = ROOT / 'config'
TEMPLATES = ROOT / 'templates'
CONFIG.mkdir(parents=True, exist_ok=True)
TEMPLATES.mkdir(parents=True, exist_ok=True)

DEFAULTS = {
    'settings': {
        'adb_path': '', 'serial': '127.0.0.1:16384',
        'match_threshold': 0.84, 'poll_seconds': 1.2,
        'battle_timeout_seconds': 600, 'safe_mode': True,
    },
    'jobs': [{
        'id': 'jp-main', 'name': '日版 FGO｜主線推圖', 'enabled': True,
        'chapter': '第一部', 'stages': [{
            'id': 'tutorial', 'name': '示範關卡（請修改）', 'repeat': 1,
            'win_template': 'quest_clear',
            'entry': [
                {'template': 'story_button', 'timeout': 25, 'optional': False},
                {'template': 'part_one', 'timeout': 25, 'optional': False},
                {'template': 'quest_node', 'timeout': 25, 'optional': False},
            ],
            'post': [
                {'template': 'result_next', 'timeout': 8, 'optional': True},
            ],
        }],
    }],
    'rules': [
        {'name': '選擇助戰（自訂模板）', 'template': 'support_first', 'enabled': True, 'cooldown': 4,
         'steps': [{'type': 'tap_match'}, {'type': 'wait', 'seconds': 1}]},
        {'name': '開始出擊（自訂模板）', 'template': 'battle_start', 'enabled': True, 'cooldown': 4,
         'steps': [{'type': 'tap_match'}, {'type': 'wait', 'seconds': 1}]},
        # Attack and command-card selection are separate screen states. Do not
        # blindly tap card coordinates on the battle screen.
        {'name': 'Attack 按鈕', 'template': 'attack_button', 'enabled': True,
         'cooldown': 5, 'steps': [{'type': 'tap_match'}, {'type': 'wait', 'seconds': 0.8}]},
    ],
    'schedules': [],
    'progress': {},
}


def read(kind):
    if kind not in DEFAULTS:
        raise ValueError('Unknown data section')
    with LOCK:
        path = CONFIG / f'{kind}.json'
        if not path.exists():
            write(kind, copy.deepcopy(DEFAULTS[kind]))
        return json.loads(path.read_text(encoding='utf-8'))


def write(kind, obj):
    if kind not in DEFAULTS:
        raise ValueError('Unknown data section')
    with LOCK:
        path = CONFIG / f'{kind}.json'
        tmp = path.with_suffix('.tmp')
        tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding='utf-8')
        os.replace(tmp, path)


def safe_template_name(name):
    if not isinstance(name, str) or not (1 <= len(name) <= 60):
        raise ValueError('圖片名稱需為 1～60 個字元')
    if not all(c.isascii() and (c.isalnum() or c in '_-') for c in name):
        raise ValueError('圖片名稱只能使用英文、數字、_、-')
    return name
