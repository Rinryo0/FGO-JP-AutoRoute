"""FGO JP AutoRoute: screen-based emulator task automation."""
__version__ = "0.1.0"
