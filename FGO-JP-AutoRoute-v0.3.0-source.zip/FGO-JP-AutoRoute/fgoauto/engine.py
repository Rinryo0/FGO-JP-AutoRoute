import copy
import datetime as dt
import threading
import time
from collections import deque

from .device import Device
from .storage import TEMPLATES, read, write
from .vision import detect_london_progress, match


class StopRequested(Exception):
    pass


class Automation:
    def __init__(self):
        self.device = Device()
        self.lock = threading.RLock()
        self.logs = deque(maxlen=240)
        self.thread = None
        self.stop_event = threading.Event()
        self.resume_event = threading.Event()
        self.resume_event.set()
        self.current = None
        self.state = 'idle'
        self.error = None
        self.last_action = ''
        self.log('FGO JP AutoRoute 啟動。請先載入路線範例並擷取自己的遊戲模板。')

    def log(self, message, level='info'):
        with self.lock:
            self.logs.appendleft({'time': dt.datetime.now().strftime('%H:%M:%S'),
                                  'level': level, 'text': str(message)})

    def status(self):
        with self.lock:
            return {'state': self.state, 'current': self.current, 'error': self.error,
                    'last_action': self.last_action, 'device': self.device.status(),
                    'logs': list(self.logs)[:90], 'progress': read('progress')}

    def start(self, job_id, safe_mode=None):
        with self.lock:
            if self.thread is not None and self.thread.is_alive():
                raise ValueError('已有任務執行中')
            jobs = read('jobs')
            job = next((job for job in jobs if job.get('id') == job_id), None)
            if not job:
                raise ValueError('找不到此任務')
            if not job.get('stages'):
                raise ValueError('任務沒有設定關卡')
            self.error = None
            self.current = {'job': job_id, 'stage': '', 'run': 0}
            self.stop_event.clear()
            self.resume_event.set()
            self.state = 'running'
            self.thread = threading.Thread(target=self._run, args=(copy.deepcopy(job), safe_mode), daemon=True)
            self.thread.start()

    def pause(self):
        with self.lock:
            if self.state == 'running':
                self.state = 'paused'
                self.resume_event.clear()
                self.log('已暫停')

    def resume(self):
        with self.lock:
            if self.state == 'paused':
                self.state = 'running'
                self.resume_event.set()
                self.log('繼續執行')

    def stop(self):
        with self.lock:
            if self.state in ('running', 'paused'):
                self.stop_event.set()
                self.resume_event.set()
                self.state = 'stopping'
                self.log('正在停止（保留進度）')

    def _check(self):
        if self.stop_event.is_set():
            raise StopRequested()
        while not self.resume_event.wait(0.25):
            if self.stop_event.is_set():
                raise StopRequested()

    def _sleep(self, seconds):
        until = time.monotonic() + max(0, float(seconds))
        while time.monotonic() < until:
            self._check()
            time.sleep(min(0.2, max(0.01, until - time.monotonic())))

    def _screen(self):
        self._check()
        return self.device.screenshot_scaled()

    def _match(self, frame, name):
        threshold = float(read('settings').get('match_threshold', 0.84))
        return match(frame, name, threshold)

    def _actions(self, steps, hit=None):
        for action in steps:
            self._check()
            action_type = action.get('type')
            if action_type == 'tap_match':
                if not hit:
                    raise ValueError('tap_match 需要已辨識的畫面')
                self.device.tap(hit.x, hit.y)
            elif action_type == 'tap':
                self.device.tap(action['x'], action['y'])
            elif action_type == 'swipe':
                self.device.swipe(action['x1'], action['y1'], action['x2'], action['y2'],
                                  action.get('duration_ms', 350))
            elif action_type == 'wait':
                self._sleep(action.get('seconds', 1))
            else:
                raise ValueError(f'未知操作類型：{action_type}')
            if action_type != 'wait':
                self._sleep(0.4)

    def _wait_template(self, name, timeout=20, optional=False, label='畫面'):
        if not name:
            raise ValueError(f'{label}未指定模板名稱')
        if not (TEMPLATES / f'{name}.png').is_file():
            if optional:
                self.log(f'略過缺少的選用模板：{name}', 'warn')
                return None
            raise ValueError(f'缺少{label}模板：{name}。請至「畫面模板」擷取。')
        end = time.monotonic() + max(1, min(180, float(timeout)))
        while True:
            frame = self._screen()
            hit = self._match(frame, name)
            if hit:
                return hit
            if time.monotonic() >= end:
                if optional:
                    self.log(f'{label}選用步驟逾時，略過：{name}', 'warn')
                    return None
                raise TimeoutError(f'{label}找不到 {name}（{timeout:.0f} 秒）')
            self._sleep(0.6)

    def _navigation(self, entries, label):
        """Execute a screen route. Template steps tap the matched template center."""
        for entry in entries:
            self._check()
            action_type = entry.get('type', 'template')
            if action_type == 'scroll_until':
                name = entry.get('template', '')
                if not (TEMPLATES / f'{name}.png').is_file():
                    raise ValueError(f'缺少捲動畫面定位模板：{name}')
                max_swipes = max(0, min(12, int(entry.get('max_swipes', 5))))
                found = False
                for attempt in range(max_swipes + 1):
                    frame = self._screen()
                    hit = self._match(frame, name)
                    if hit:
                        self.log(f'{label}：已找到 {name}（第 {attempt} 次滑動）')
                        found = True
                        break
                    if attempt >= max_swipes:
                        break
                    self.device.swipe(entry['x1'], entry['y1'], entry['x2'], entry['y2'],
                                      entry.get('duration_ms', 450))
                    self._sleep(float(entry.get('settle_seconds', 0.8)))
                if not found:
                    raise TimeoutError(f'{label}：滑動 {max_swipes} 次仍找不到 {name}')
                continue
            if action_type in ('template', 'wait_template'):
                name = entry.get('template')
                hit = self._wait_template(name, entry.get('timeout', 20),
                                          bool(entry.get('optional', False)), label)
                if hit and action_type == 'template':
                    self.log(f'{label}：點擊 {name}（{hit.score:.2f}）')
                    self.device.tap(hit.x, hit.y)
                    self._sleep(float(entry.get('settle_seconds', 0.9)))
                continue
            if action_type in ('tap', 'swipe', 'wait'):
                self._actions([entry])
                continue
            raise ValueError(f'{label}：未知路線步驟 {action_type}')

    def _fight(self, stage):
        win_name = stage.get('win_template', '')
        if not win_name or not (TEMPLATES / f'{win_name}.png').is_file():
            raise ValueError(f'缺少勝利判定模板：{win_name or "未設定"}；不能安全計算通關次數。')
        required = stage.get('required_rule_templates', [])
        missing = [name for name in required if not (TEMPLATES / f'{name}.png').is_file()]
        if missing:
            raise ValueError('缺少必要戰鬥規則模板：' + ', '.join(missing))
        rules = [r for r in read('rules') if r.get('enabled') and
                 (TEMPLATES / (str(r.get('template')) + '.png')).is_file()]
        if not rules:
            raise ValueError('尚未擷取任何可用的戰鬥規則模板。')
        last_trigger = {}
        start = time.monotonic()
        timeout = float(read('settings').get('battle_timeout_seconds', 600))
        idle_start = time.monotonic()
        while time.monotonic() - start < timeout:
            frame = self._screen()
            win_hit = self._match(frame, win_name)
            if win_hit:
                self.log(f'偵測到勝利結算標記：{win_name}（{win_hit.score:.2f}）')
                return
            found = False
            for rule in rules:
                name = rule.get('template')
                hit = self._match(frame, name)
                if not hit:
                    continue
                now = time.monotonic()
                if now - last_trigger.get(name, -1e10) < float(rule.get('cooldown', 3)):
                    continue
                self.log(f'戰鬥規則：{rule.get("name", name)}（{hit.score:.2f}）')
                self.last_action = rule.get('name', name)
                self._actions(rule.get('steps', [{'type': 'tap_match'}]), hit)
                last_trigger[name] = time.monotonic()
                idle_start = time.monotonic()
                found = True
                break
            if not found:
                if time.monotonic() - idle_start > 90:
                    raise TimeoutError('90 秒內沒有辨識出可操作畫面，已安全停止（可能卡關、AP 不足或出現未配置彈窗）。')
                self._sleep(float(read('settings').get('poll_seconds', 1.2)))
        raise TimeoutError(f'戰鬥逾時（{timeout:.0f} 秒），已停止。')

    def _clear_detected(self, stage, seconds=4):
        name = stage.get('clear_template', '')
        if not name or not (TEMPLATES / f'{name}.png').is_file():
            raise ValueError(f'動態推關必須先建立通關狀態模板：{name or "未指定"}')
        end = time.monotonic() + seconds
        while time.monotonic() <= end:
            frame = self._screen()
            if self._match(frame, name):
                self.log(f'畫面確認關卡完成：{name}')
                return True
            self._sleep(0.8)
        return False

    def _read_progress_arrows(self, stage):
        anchor = stage.get('progress_anchor_template', '')
        if not anchor or not (TEMPLATES / f'{anchor}.png').is_file():
            raise ValueError(f'缺少進行度定位模板：{anchor or "未指定"}')
        frame = self._screen()
        hit = self._match(frame, anchor)
        if not hit:
            raise TimeoutError(f'目前畫面找不到任務列模板 {anchor}，無法安全讀取進行度。')
        result = detect_london_progress(frame)
        self.log(f'辨識任務進行度：{result["progress"]}/{result["target_slots"]}（藍色箭頭 {result["active_slots"] or "無"}）')
        return result

    def _run_progress_stage(self, job, stage, progress):
        stage_id = stage['id']
        job_progress = progress.setdefault(job['id'], {})
        target = max(1, min(5, int(stage.get('progress_target', 5))))
        max_runs = max(1, min(30, int(stage.get('max_runs', 7))))
        if job_progress.get(stage_id + '__done'):
            self.log(f'已完成進行度目標，略過：{stage.get("name", stage_id)}')
            return
        completed = max(0, min(target, int(job_progress.get(stage_id + '__progress', 0))))
        attempts = max(0, int(job_progress.get(stage_id + '__runs', 0)))
        first_in_session = True
        while completed < target and attempts < max_runs:
            self._check()
            with self.lock:
                self.current = {'job': job['id'], 'stage': stage_id,
                                'stage_name': stage.get('name', stage_id),
                                'run': completed, 'required': target}
            self.log(f'開始 {stage.get("name", stage_id)}：進行度 {completed}/{target}，本機工作階段第 {attempts + 1} 次戰鬥')
            if first_in_session:
                self._navigation(stage.get('entry', []), '首次進入關卡')
                first_in_session = False
            else:
                self._navigation(stage.get('repeat_entry') or stage.get('entry', []), '再次進入同一進行度任務')
            self._fight(stage)
            attempts += 1
            job_progress[stage_id + '__runs'] = attempts
            write('progress', progress)
            self.log('勝利已確認，開始處理結算頁')
            self._navigation(stage.get('post', []), '戰鬥結算')
            observed = self._read_progress_arrows(stage)
            new_value = int(observed['progress'])
            if new_value <= completed:
                raise TimeoutError(
                    f'戰鬥後進行度沒有增加（仍為 {new_value}/{target}）。已停止，避免重複刷錯關卡。'
                )
            if new_value > target:
                raise ValueError(f'辨識到進行度 {new_value}，超過設定目標 {target}；請檢查進度列模板與目標值。')
            completed = new_value
            job_progress[stage_id + '__progress'] = completed
            write('progress', progress)
            self.log(f'已儲存進度：{completed}/{target}')
        if completed < target:
            raise TimeoutError(f'已達安全戰鬥上限 {max_runs} 次，但進行度只有 {completed}/{target}；已停止。')
        job_progress[stage_id + '__done'] = True
        write('progress', progress)
        self.log(f'進行度 {target}/{target} 已完成：{stage.get("name", stage_id)}')

    def _run_fixed_stage(self, job, stage, progress):
        stage_id = stage['id']
        job_progress = progress.setdefault(job['id'], {})
        mode = stage.get('mode', 'fixed')
        if mode == 'until_clear':
            limit = max(1, min(999, int(stage.get('max_runs', 15))))
        else:
            limit = max(1, min(999, int(stage.get('repeat', 1))))
        cleared = min(limit, int(job_progress.get(stage_id, 0)))
        if mode == 'until_clear' and job_progress.get(stage_id + '__done'):
            self.log(f'已確認完成，略過關卡：{stage.get("name", stage_id)}')
            return
        if mode == 'until_clear' and stage.get('check_clear_before') and self._clear_detected(stage, 2):
            job_progress[stage_id + '__done'] = True
            write('progress', progress)
            return
        first_in_session = True
        done = False
        while cleared < limit:
            self._check()
            with self.lock:
                self.current = {'job': job['id'], 'stage': stage_id,
                                'stage_name': stage.get('name', stage_id),
                                'run': cleared, 'required': limit}
            self.log(f'進入 {stage.get("name", stage_id)}，已完成 {cleared}/{limit}')
            if first_in_session:
                self._navigation(stage.get('entry', []), '進入關卡')
                first_in_session = False
            else:
                self._navigation(stage.get('repeat_entry') or stage.get('entry', []), '再次進入關卡')
            self._fight(stage)
            cleared += 1
            job_progress[stage_id] = cleared
            write('progress', progress)
            self.log(f'累計勝利 {cleared}/{limit}，已儲存進度')
            self._navigation(stage.get('post', []), '結算後操作')
            if mode == 'until_clear' and self._clear_detected(stage, 7):
                done = True
                break
        if mode == 'until_clear':
            if not done:
                raise TimeoutError(f'刷關已達安全上限 {limit} 次，仍未確認通關標記；為防誤刷已停止。')
            job_progress[stage_id + '__done'] = True
            write('progress', progress)
        self.log(f'關卡完成：{stage.get("name", stage_id)}，準備前往下一關')

    def _run(self, job, safe_mode):
        try:
            settings = read('settings')
            if safe_mode is None:
                safe_mode = bool(settings.get('safe_mode', True))
            if safe_mode:
                missing = []
                for stage in job['stages']:
                    for step in stage.get('entry', []) + stage.get('repeat_entry', []) + stage.get('post', []):
                        name = step.get('template')
                        if name and not step.get('optional') and not (TEMPLATES / f'{name}.png').is_file():
                            missing.append(name)
                    win_name = stage.get('win_template')
                    if not win_name or not (TEMPLATES / f'{win_name}.png').is_file():
                        missing.append(win_name or 'win_template')
                    anchor = stage.get('progress_anchor_template')
                    if stage.get('mode') == 'progress_arrows' and (not anchor or not (TEMPLATES / f'{anchor}.png').is_file()):
                        missing.append(anchor or 'progress_anchor_template')
                    if stage.get('mode') == 'until_clear':
                        clear_name = stage.get('clear_template')
                        if not clear_name or not (TEMPLATES / f'{clear_name}.png').is_file():
                            missing.append(clear_name or 'clear_template')
                    for name in stage.get('required_rule_templates', []):
                        if not (TEMPLATES / f'{name}.png').is_file():
                            missing.append(name)
                self.log('安全預檢：不會點擊遊戲畫面。')
                if missing:
                    raise ValueError('預檢缺少模板：' + ', '.join(sorted(set(filter(None, missing)))))
                self.log('預檢通過：必要模板齊全；請先監看一次完整測試。')
                return
            self.device.connect()
            progress = read('progress')
            for stage in job['stages']:
                self._check()
                if stage.get('mode') == 'progress_arrows':
                    self._run_progress_stage(job, stage, progress)
                else:
                    self._run_fixed_stage(job, stage, progress)
                progress = read('progress')
            self.log('整條關卡路線已完成！')
        except StopRequested:
            self.log('任務已停止，進度已保留')
        except Exception as exc:
            self.error = str(exc)
            self.log(f'任務停止：{exc}', 'error')
        finally:
            with self.lock:
                self.state = 'idle'
                self.current = None
                self.resume_event.set()


class Scheduler:
    def __init__(self, automation):
        self.automation = automation
        self.fired = set()
        self.thread = threading.Thread(target=self.loop, daemon=True)
        self.thread.start()

    def loop(self):
        while True:
            try:
                now = dt.datetime.now().astimezone()
                stamp = now.strftime('%Y-%m-%d %H:%M')
                if len(self.fired) > 300:
                    self.fired = set()
                for schedule in read('schedules'):
                    if not schedule.get('enabled', True):
                        continue
                    if schedule.get('time') != now.strftime('%H:%M'):
                        continue
                    if now.weekday() not in schedule.get('weekdays', list(range(7))):
                        continue
                    key = (schedule.get('id'), stamp)
                    if key in self.fired:
                        continue
                    self.fired.add(key)
                    try:
                        self.automation.start(schedule['job_id'])
                        self.automation.log(f'排程啟動：{schedule.get("name", "") }')
                    except ValueError as e:
                        self.automation.log(f'排程略過：{e}', 'warn')
            except Exception as e:
                self.automation.log(f'排程錯誤：{e}', 'error')
            time.sleep(5)
