from dataclasses import dataclass

import cv2
import numpy as np

from .storage import TEMPLATES, safe_template_name


@dataclass
class Match:
    name: str
    score: float
    x: float
    y: float


def match(frame, name, threshold=0.84):
    safe_template_name(name)
    path = TEMPLATES / f'{name}.png'
    if not path.is_file():
        return None
    tpl = cv2.imread(str(path), cv2.IMREAD_GRAYSCALE)
    if tpl is None:
        return None
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    h, w = tpl.shape[:2]
    if h > gray.shape[0] or w > gray.shape[1] or h < 6 or w < 6:
        return None
    result = cv2.matchTemplate(gray, tpl, cv2.TM_CCOEFF_NORMED)
    _, score, _, loc = cv2.minMaxLoc(result)
    if score < threshold:
        return None
    x = (loc[0] + w / 2) / gray.shape[1]
    y = (loc[1] + h / 2) / gray.shape[0]
    return Match(name=name, score=float(score), x=x, y=y)


# Coordinates calibrated from the two supplied 1280x720 London quest-list
# screenshots: five chevrons occupy this fixed row below "クエスト進行度".
# The active progress chevron is a bright cyan/blue; inactive chevrons are grey.
LONDON_PROGRESS_SLOTS = (
    (901, 938),
    (940, 977),
    (979, 1016),
    (1018, 1055),
    (1057, 1094),
)
LONDON_PROGRESS_Y = (194, 225)


def detect_london_progress(frame, pixel_threshold=80):
    """Return the highest active London quest-progress chevron (0..5).

    The caller must first verify that the London quest-row anchor is visible.
    This prevents unrelated blue UI elements on other screens being read as
    progress. It intentionally returns 0 when no bright-blue chevron exists.
    """
    if frame is None or frame.ndim != 3 or frame.shape[1] < 1094 or frame.shape[0] < 225:
        raise ValueError('進行度辨識需要至少 1094×225 的彩色畫面')
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    mask = cv2.inRange(
        hsv,
        np.array([90, 100, 120], dtype=np.uint8),
        np.array([130, 255, 255], dtype=np.uint8),
    )
    y1, y2 = LONDON_PROGRESS_Y
    counts = []
    for x1, x2 in LONDON_PROGRESS_SLOTS:
        count = int(cv2.countNonZero(mask[y1:y2, x1:x2]))
        counts.append(count)
    active = [index + 1 for index, count in enumerate(counts) if count >= pixel_threshold]
    return {
        'progress': max(active, default=0),
        'active_slots': active,
        'blue_pixel_counts': counts,
        'target_slots': len(LONDON_PROGRESS_SLOTS),
    }
