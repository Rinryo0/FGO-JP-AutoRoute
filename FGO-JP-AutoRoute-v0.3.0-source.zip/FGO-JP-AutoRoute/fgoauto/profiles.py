"""Built-in route profiles based on the user's observed FGO JP UI.

Only text configuration and normalized input coordinates are shipped here.
No game screenshots or extracted game-art templates are bundled.
"""

LONDON_GUIDE = [
    {
        "name": "london_chapter_tile",
        "screen": "主畫面／主線章節清單",
        "crop": "第四特異點「死界魔霧都市 ロンドン」章節橫幅的標題區；避開右側橘色數字徽章",
        "required": True,
        "purpose": "從終端畫面進入第四特異點",
    },
    {
        "name": "london_next_node",
        "screen": "第四特異點倫敦地圖",
        "crop": "City of London 節點上的 NEXT 箭頭與藍色節點，盡量一起框選",
        "required": True,
        "purpose": "打開倫敦第六節所在的節點任務清單",
    },
    {
        "name": "london_quest_row",
        "screen": "節點任務清單",
        "crop": "「ロンドン・ナイト」任務列左上標題區；不要把進行度箭頭、AP 數字或獎勵圖示框進去",
        "required": True,
        "purpose": "選擇第六節，並作為五格進行度偵測的畫面錨點",
    },
    {
        "name": "support_guest",
        "screen": "支援選擇",
        "crop": "你希望固定選擇的支援從者卡片左側頭像或 Guest Servant 標籤",
        "required": True,
        "purpose": "選擇支援從者；若要換支援，重新擷取這張模板",
    },
    {
        "name": "party_start",
        "screen": "隊伍確認",
        "crop": "右下角「クエスト開始」按鈕中央",
        "required": True,
        "purpose": "開始主線戰鬥",
    },
    {
        "name": "story_skip",
        "screen": "劇情對話",
        "crop": "右上角 SKIP 按鈕",
        "required": True,
        "purpose": "開啟跳過劇情確認視窗",
    },
    {
        "name": "skip_confirm_yes",
        "screen": "跳過劇情確認視窗",
        "crop": "右側「はい」按鈕中央，不要包含左側「いいえ」",
        "required": True,
        "purpose": "確認跳過劇情",
    },
    {
        "name": "dialogue_next",
        "screen": "劇情對話",
        "crop": "右下角藍色菱形下一句提示；作為無法跳過時的備援",
        "required": False,
        "purpose": "自動推進沒有 SKIP 的對話",
    },
    {
        "name": "attack_button",
        "screen": "戰鬥指令畫面",
        "crop": "右下角藍色 Attack 按鈕中央",
        "required": True,
        "purpose": "打開指令卡選擇畫面",
    },
    {
        "name": "card_select_state",
        "screen": "指令卡選擇畫面",
        "crop": "右上角 BATTLE SPEED 按鈕的文字與外框，或其他穩定且獨特的區域",
        "required": True,
        "purpose": "確認已進入指令卡畫面，再選擇前三張卡",
    },
    {
        "name": "result_continue",
        "screen": "Bond／Master EXP 結算畫面",
        "crop": "畫面下方「画面をタッチしてください」提示文字",
        "required": True,
        "purpose": "推進羈絆升級與 Master EXP 結算頁",
    },
    {
        "name": "victory_exp",
        "screen": "Master EXP 結算畫面",
        "crop": "右側「獲得EXP」標題文字；這是勝利判定，不要只截 RESULT 標題",
        "required": True,
        "purpose": "確認已勝利，避免把敗北結算計入進度",
    },
    {
        "name": "loot_next",
        "screen": "獲得戰利品畫面",
        "crop": "右下角「次へ」按鈕中央",
        "required": True,
        "purpose": "結束獎勵頁並返回任務清單",
    },
]

LONDON_RULES = [
    {
        "name": "跳過劇情",
        "template": "story_skip",
        "enabled": True,
        "cooldown": 8,
        "steps": [{"type": "tap_match"}, {"type": "wait", "seconds": 0.8}],
    },
    {
        "name": "確認跳過劇情",
        "template": "skip_confirm_yes",
        "enabled": True,
        "cooldown": 8,
        "steps": [{"type": "tap_match"}, {"type": "wait", "seconds": 1.2}],
    },
    {
        "name": "對話自動前進（備援）",
        "template": "dialogue_next",
        "enabled": True,
        "cooldown": 1.8,
        "steps": [{"type": "tap_match"}],
    },
    {
        "name": "戰鬥 Attack",
        "template": "attack_button",
        "enabled": True,
        "cooldown": 5,
        "steps": [{"type": "tap_match"}, {"type": "wait", "seconds": 0.8}],
    },
    {
        "name": "選擇前三張指令卡（基礎策略）",
        "template": "card_select_state",
        "enabled": True,
        "cooldown": 5,
        "steps": [
            {"type": "tap", "x": 0.13, "y": 0.73},
            {"type": "wait", "seconds": 0.35},
            {"type": "tap", "x": 0.33, "y": 0.73},
            {"type": "wait", "seconds": 0.35},
            {"type": "tap", "x": 0.53, "y": 0.73},
        ],
    },
    {
        "name": "羈絆升級頁繼續",
        "template": "result_continue",
        "enabled": True,
        "cooldown": 3,
        "steps": [{"type": "tap_match"}, {"type": "wait", "seconds": 1.0}],
    },
]


def london_job():
    return {
        "id": "jp-london-4th-section-06",
        "name": "日版 FGO｜第四特異點 倫敦・第六節",
        "enabled": True,
        "chapter": "第一部",
        "profile": "london-4th-section-06",
        "stages": [
            {
                "id": "london-night-06",
                "name": "ロンドン・ナイト（第6節）",
                "mode": "progress_arrows",
                "progress_target": 5,
                "progress_anchor_template": "london_quest_row",
                "max_runs": 7,
                "win_template": "victory_exp",
                "required_rule_templates": [
                    "story_skip", "skip_confirm_yes", "attack_button",
                    "card_select_state", "result_continue",
                ],
                "entry": [
                    {
                        "type": "scroll_until",
                        "template": "london_chapter_tile",
                        "timeout": 35,
                        "max_swipes": 5,
                        "x1": 0.78,
                        "y1": 0.80,
                        "x2": 0.78,
                        "y2": 0.32,
                        "duration_ms": 450,
                    },
                    {"type": "template", "template": "london_chapter_tile", "timeout": 12},
                    {"type": "template", "template": "london_next_node", "timeout": 30},
                    {"type": "template", "template": "london_quest_row", "timeout": 20},
                    {"type": "template", "template": "support_guest", "timeout": 45},
                    {"type": "template", "template": "party_start", "timeout": 25},
                ],
                "repeat_entry": [
                    {"type": "template", "template": "london_quest_row", "timeout": 25},
                    {"type": "template", "template": "support_guest", "timeout": 45},
                    {"type": "template", "template": "party_start", "timeout": 25},
                ],
                "post": [
                    {"type": "template", "template": "result_continue", "timeout": 25},
                    {"type": "template", "template": "loot_next", "timeout": 25},
                    {"type": "wait_template", "template": "london_quest_row", "timeout": 35},
                ],
            }
        ],
    }
