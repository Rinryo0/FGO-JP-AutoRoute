import shutil
import subprocess
from pathlib import Path

import cv2
import numpy as np

from .storage import read

CANONICAL_SIZE = (1280, 720)
MU_PORTS = [16384, 16385, 16416, 16417, 16448, 16449, 16480, 16512, 16544, 16576, 7555]


class DeviceError(RuntimeError):
    pass


def locate_adb(configured=''):
    candidates = [configured] if configured else []
    found = shutil.which('adb')
    if found:
        candidates.append(found)
    candidates.extend([
        r'C:\Program Files\MuMuVMMVbox\Hypervisor\adb.exe',
        r'C:\Program Files\Netease\MuMu Player 12\shell\adb.exe',
        r'C:\Program Files (x86)\Nemu\vmonitor\bin\adb_server.exe',
    ])
    for path in candidates:
        if path and Path(path).is_file():
            return str(Path(path))
    raise DeviceError('找不到 adb。請安裝 Android Platform Tools，或在設定填寫 adb.exe 的完整路徑。')


class Device:
    def __init__(self):
        self.serial = None
        self.exe = None

    def connect(self, serial=None):
        settings = read('settings')
        self.exe = locate_adb(settings.get('adb_path', ''))
        serial = serial or settings.get('serial', '127.0.0.1:16384')
        if serial == 'auto':
            for port in MU_PORTS:
                try:
                    self._run(['connect', f'127.0.0.1:{port}'], timeout=3)
                    output = self._run(['-s', f'127.0.0.1:{port}', 'get-state'], timeout=3)
                    if b'device' in output:
                        self.serial = f'127.0.0.1:{port}'
                        return self.serial
                except DeviceError:
                    pass
            raise DeviceError('無法自動連接 MuMu 12，請確認開啟 ADB 偵錯及模擬器。')
        if not serial.startswith('127.0.0.1:'):
            raise DeviceError('僅允許連線本機 MuMu 模擬器 (127.0.0.1)。')
        self._run(['connect', serial], timeout=6)
        state = self._run(['-s', serial, 'get-state'], timeout=5).decode(errors='replace').strip()
        if state != 'device':
            raise DeviceError(f'ADB 裝置狀態：{state}')
        self.serial = serial
        return serial

    def _run(self, args, timeout=12):
        if not self.exe:
            self.exe = locate_adb(read('settings').get('adb_path', ''))
        try:
            cp = subprocess.run([self.exe, *args], capture_output=True, timeout=timeout,
                                creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        except (OSError, subprocess.TimeoutExpired) as e:
            raise DeviceError(f'ADB 執行失敗：{e}') from e
        if cp.returncode != 0:
            raise DeviceError(cp.stderr.decode(errors='replace').strip() or 'ADB 指令失敗')
        return cp.stdout

    def _adb(self, args, timeout=12):
        if not self.serial:
            self.connect()
        return self._run(['-s', self.serial, *args], timeout=timeout)

    def screenshot(self):
        data = self._adb(['exec-out', 'screencap', '-p'], timeout=18)
        frame = cv2.imdecode(np.frombuffer(data, np.uint8), cv2.IMREAD_COLOR)
        if frame is None:
            raise DeviceError('ADB 截圖失敗，請確認模擬器畫面正常。')
        return frame

    def screenshot_scaled(self):
        return cv2.resize(self.screenshot(), CANONICAL_SIZE, interpolation=cv2.INTER_AREA)

    def tap(self, x, y):
        frame = self.screenshot()
        height, width = frame.shape[:2]
        # normalized 0..1, independent of emulator display resolution
        xx = int(max(0, min(1, float(x))) * (width - 1))
        yy = int(max(0, min(1, float(y))) * (height - 1))
        self._adb(['shell', 'input', 'tap', str(xx), str(yy)], timeout=8)

    def swipe(self, x1, y1, x2, y2, duration_ms=350):
        frame = self.screenshot()
        height, width = frame.shape[:2]
        xy = [int(max(0, min(1, float(v))) * (width - 1 if i % 2 == 0 else height - 1))
              for i, v in enumerate((x1, y1, x2, y2))]
        self._adb(['shell', 'input', 'swipe', *map(str, xy), str(int(duration_ms))], timeout=10)

    def status(self):
        return {'connected': bool(self.serial), 'serial': self.serial}
