The app creates local JSON settings here on first launch. These JSON files are ignored by git.
