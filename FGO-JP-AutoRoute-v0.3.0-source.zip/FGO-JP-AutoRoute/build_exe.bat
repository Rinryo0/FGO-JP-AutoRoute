@echo off
chcp 65001 >nul
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel% equ 0 (set "PY=py -3") else (set "PY=python")
%PY% --version
if errorlevel 1 (
  echo Developer build requires Python 3.11+.
  pause
  exit /b 1
)
%PY% -m pip install --upgrade pip
%PY% -m pip install -r requirements.txt pytest "pyinstaller>=6.10,<7"
if errorlevel 1 goto :error
%PY% -m pytest -q
if errorlevel 1 goto :error
%PY% -m PyInstaller --noconfirm --clean --onefile --windowed --name FGO-JP-AutoRoute --add-data "web;web" --collect-all cv2 --collect-all numpy --collect-all flask app.py
if errorlevel 1 goto :error
echo.
echo Build complete: dist\FGO-JP-AutoRoute.exe
pause
exit /b 0
:error
echo Build failed. See the error above.
pause
exit /b 1
