@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist .git (
  echo This folder is not a Git clone. Use GitHub Desktop to clone the repository first.
  pause
  exit /b 1
)
git pull --ff-only
if errorlevel 1 (
  echo Pull failed: resolve changes using GitHub Desktop.
  pause
  exit /b 1
)
if exist ".venv\Scripts\python.exe" ".venv\Scripts\python.exe" -m pip install -r requirements.txt
echo Update finished.
pause
