@echo off
chcp 65001 >nul
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Please run install.bat first.
  pause
  exit /b 1
)
start "" "http://127.0.0.1:3789"
echo FGO JP AutoRoute running at http://127.0.0.1:3789
echo Keep this window open to use the scheduler. Press Ctrl+C to stop.
".venv\Scripts\python.exe" app.py
pause
