"""Local web UI. Run the standalone EXE or python app.py for development."""
import datetime as dt
import io
import logging
import re
import threading
import uuid
import webbrowser
from pathlib import Path

import cv2
from flask import Flask, Response, jsonify, render_template, request

from fgoauto.engine import Automation, Scheduler
from fgoauto.storage import RESOURCE_ROOT, ROOT, TEMPLATES, read, safe_template_name, write
from fgoauto.profiles import LONDON_GUIDE, LONDON_RULES, london_job
from fgoauto.vision import detect_london_progress

app = Flask(__name__, template_folder=str(RESOURCE_ROOT / 'web'),
            static_folder=str(RESOURCE_ROOT / 'web' / 'assets'))
app.json.ensure_ascii = False
bot = Automation()
scheduler = Scheduler(bot)
last_capture = None


def fail(message, status=400):
    return jsonify({'ok': False, 'error': str(message)}), status


@app.errorhandler(Exception)
def error_handler(error):
    if hasattr(error, 'code') and getattr(error, 'code') == 404:
        return fail('找不到此功能', 404)
    return fail(error)


@app.get('/')
def index():
    return render_template('index.html')


@app.get('/api/status')
def status():
    return jsonify({'ok': True, **bot.status()})


@app.get('/api/<kind>')
def load_data(kind):
    if kind not in ('settings', 'jobs', 'rules', 'schedules'):
        return fail('不允許的設定項目')
    return jsonify({'ok': True, 'data': read(kind)})


@app.put('/api/<kind>')
def save_data(kind):
    if kind not in ('settings', 'jobs', 'rules', 'schedules'):
        return fail('不允許的設定項目')
    data = request.get_json(force=True)
    if kind == 'settings':
        if not isinstance(data, dict):
            return fail('設定需為 JSON 物件')
        if not (0.5 <= float(data.get('match_threshold', 0.84)) <= 0.99):
            return fail('辨識門檻請輸入 0.5～0.99')
        if data.get('serial') != 'auto' and not str(data.get('serial', '')).startswith('127.0.0.1:'):
            return fail('只能連線本機 MuMu')
    else:
        if not isinstance(data, list):
            return fail('設定需為 JSON 陣列')
        if kind == 'jobs':
            for job in data:
                if not job.get('id') or not isinstance(job.get('stages'), list):
                    return fail('每個任務都需要 ID 和 stages 陣列')
                for stage in job['stages']:
                    if not stage.get('id') or not 1 <= int(stage.get('repeat', 1)) <= 999:
                        return fail('關卡需要 ID，重複次數需為 1～999')
                    for field in ('entry', 'repeat_entry', 'post'):
                        if field in stage and not isinstance(stage[field], list):
                            return fail(f'{field} 必須是 JSON 陣列')
                    if stage.get('mode') == 'progress_arrows':
                        if not 1 <= int(stage.get('progress_target', 5)) <= 5:
                            return fail('進行度目標需為 1～5')
        if kind == 'schedules':
            for task in data:
                if not re.fullmatch(r'\d\d:\d\d', str(task.get('time', ''))):
                    return fail('排程時間格式為 HH:MM')
    write(kind, data)
    bot.log(f'已儲存 {kind} 設定')
    return jsonify({'ok': True})


@app.get('/api/profiles/london/guide')
def london_guide():
    names = {p.stem for p in TEMPLATES.glob('*.png')}
    guide = []
    for item in LONDON_GUIDE:
        guide.append({**item, 'captured': item['name'] in names})
    return jsonify({'ok': True, 'data': guide})


@app.post('/api/profiles/london/apply')
def apply_london_profile():
    if bot.state != 'idle':
        return fail('任務執行中不能套用路線')
    job = london_job()
    jobs = read('jobs')
    existing = next((i for i, item in enumerate(jobs) if item.get('id') == job['id']), None)
    if existing is None:
        jobs.append(job)
    else:
        jobs[existing] = job
    write('jobs', jobs)

    rules = read('rules')
    for new_rule in LONDON_RULES:
        index = next((i for i, item in enumerate(rules) if item.get('template') == new_rule['template']), None)
        if index is None:
            rules.append(new_rule)
        else:
            rules[index] = new_rule
    write('rules', rules)
    bot.log('已載入倫敦第四特異點第六節範例路線與戰鬥規則。請先依模板清單擷取畫面。')
    return jsonify({'ok': True, 'job_id': job['id'], 'guide_count': len(LONDON_GUIDE)})


@app.get('/api/device/progress')
def device_progress():
    anchor_name = 'london_quest_row'
    if not (TEMPLATES / f'{anchor_name}.png').is_file():
        return fail('請先擷取 london_quest_row 模板')
    frame = bot.device.screenshot_scaled()
    from fgoauto.vision import match
    hit = match(frame, anchor_name, float(read('settings').get('match_threshold', 0.84)))
    if not hit:
        return fail('目前畫面未辨識到倫敦第六節任務列；請先打開「ロンドン・ナイト」任務清單')
    result = detect_london_progress(frame)
    return jsonify({'ok': True, **result})


@app.post('/api/device/connect')
def connect():
    bot.device.connect()
    bot.log(f'已連接 MuMu：{bot.device.serial}')
    return jsonify({'ok': True, 'serial': bot.device.serial})


@app.get('/api/device/screenshot')
def screenshot():
    frame = bot.device.screenshot_scaled()
    ok, jpg = cv2.imencode('.jpg', frame, [cv2.IMWRITE_JPEG_QUALITY, 82])
    if not ok:
        return fail('截圖轉換失敗')
    return Response(jpg.tobytes(), mimetype='image/jpeg', headers={'Cache-Control': 'no-store'})


@app.post('/api/device/tap')
def tap():
    if bot.state != 'idle':
        return fail('任務進行中不可手動點擊')
    data = request.get_json(force=True)
    bot.device.tap(float(data['x']), float(data['y']))
    return jsonify({'ok': True})


@app.get('/api/templates')
def templates():
    names = sorted(p.stem for p in TEMPLATES.glob('*.png'))
    return jsonify({'ok': True, 'data': names})


@app.get('/api/device/capture')
def capture_for_template():
    global last_capture
    frame = bot.device.screenshot_scaled()
    last_capture = frame.copy()
    ok, image = cv2.imencode('.jpg', frame, [cv2.IMWRITE_JPEG_QUALITY, 88])
    if not ok:
        return fail('畫面轉換失敗')
    return Response(image.tobytes(), mimetype='image/jpeg', headers={'Cache-Control': 'no-store'})


@app.post('/api/templates')
def create_template():
    data = request.get_json(force=True)
    name = safe_template_name(data.get('name', ''))
    x, y, w, h = (int(data[k]) for k in ('x', 'y', 'w', 'h'))
    if not (0 <= x < 1280 and 0 <= y < 720 and 12 <= w <= 800 and 12 <= h <= 500
            and x + w <= 1280 and y + h <= 720):
        return fail('截圖範圍錯誤，請重新框選（至少 12×12）')
    if last_capture is None:
        return fail('請先按「取得畫面」再框選')
    crop = last_capture[y:y+h, x:x+w]
    ok = cv2.imwrite(str(TEMPLATES / (name + '.png')), crop)
    if not ok:
        return fail('無法儲存模板')
    bot.log(f'已擷取畫面模板：{name}（{w}×{h}）')
    return jsonify({'ok': True, 'name': name})


@app.delete('/api/templates/<name>')
def delete_template(name):
    safe_template_name(name)
    (TEMPLATES / f'{name}.png').unlink(missing_ok=True)
    return jsonify({'ok': True})


@app.post('/api/run/<action>')
def run_action(action):
    body = request.get_json(silent=True) or {}
    if action == 'start':
        bot.start(body.get('job_id', 'jp-main'), body.get('safe_mode'))
    elif action == 'pause':
        bot.pause()
    elif action == 'resume':
        bot.resume()
    elif action == 'stop':
        bot.stop()
    else:
        return fail('未知的任務操作')
    return jsonify({'ok': True})


@app.post('/api/progress/reset')
def reset_progress():
    if bot.state != 'idle':
        return fail('請先停止任務')
    body = request.get_json(force=True)
    job = body.get('job_id')
    progress = read('progress')
    progress.pop(job, None)
    write('progress', progress)
    bot.log(f'已重設任務進度：{job}', 'warn')
    return jsonify({'ok': True})


if __name__ == '__main__':
    # Frozen EXE has no console window; retain a startup log for troubleshooting.
    log_dir = ROOT / 'logs'
    log_dir.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(
        filename=str(log_dir / 'app.log'), level=logging.INFO,
        format='%(asctime)s %(levelname)s %(message)s', encoding='utf-8'
    )
    url = 'http://127.0.0.1:3789'
    logging.info('Starting FGO JP AutoRoute')
    threading.Timer(1.3, lambda: webbrowser.open_new_tab(url)).start()
    try:
        app.run(host='127.0.0.1', port=3789, debug=False, threaded=True, use_reloader=False)
    except OSError as exc:
        logging.exception('Could not start local web server')
        if getattr(__import__('sys'), 'frozen', False):
            import ctypes
            ctypes.windll.user32.MessageBoxW(
                None,
                f'無法啟動 FGO JP AutoRoute：{exc}\n請確認 3789 連接埠沒有被其他程式占用。\n日誌位置：{log_dir / "app.log"}',
                'FGO JP AutoRoute', 0x10
            )
        else:
            raise
