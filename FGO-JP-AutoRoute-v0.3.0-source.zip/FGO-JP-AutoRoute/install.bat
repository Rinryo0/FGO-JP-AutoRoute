@echo off
chcp 65001 >nul
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel% equ 0 (set "PY=py -3") else (set "PY=python")
%PY% --version
if errorlevel 1 (
  echo Please install Python 3.11 or later from python.org and enable Add to PATH.
  pause
  exit /b 1
)
if not exist ".venv\Scripts\python.exe" (
  %PY% -m venv .venv
  if errorlevel 1 goto :error
)
".venv\Scripts\python.exe" -m pip install --upgrade pip
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto :error
echo Installation finished. Double-click start.bat.
pause
exit /b 0
:error
echo Installation failed. Check Python and internet connection.
pause
exit /b 1
