Use the built-in capture screen to create template images. Personal game screenshots are ignored by git.
