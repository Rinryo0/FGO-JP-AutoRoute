# FGO JP AutoRoute（日版 FGO 自動推圖）

適用：**Windows 11 + MuMu 模擬器 12 + 日版 Fate/Grand Order**。

這是持續開發中的 **v0.3.0 開源專案**，以 [AzurLaneAutoScript](https://github.com/LmeSzinc/AzurLaneAutoScript) 的「深色儀表板／路線管理／排程／日誌」工作方式為參考，**並非 ALAS 的修改版或官方合作軟體**。

> ⚠️ 請先讀：本專案包含真正的 ADB 截圖、畫面比對及點擊功能，但是 **沒有附帶已校準的日版 FGO 介面截圖，因此首次解壓後不能一鍵自動通關所有章節**。必須先從自己的日版遊戲截取按鈕模板、配置每一個故事關卡的路線與戰鬥規則。日版 UI、故事選項、助戰角色、特殊機制及更新後的畫面都會影響準確度。未於實際 MuMu 遊戲環境做通關驗證。


## 免安裝 Python 版本（推薦一般使用者）

GitHub Actions 會在 Windows x64 runner 上編譯單檔 `FGO-JP-AutoRoute.exe`。一般使用者**不需要安裝 Python、pip 或任何 Python 套件**：

1. 到 GitHub 專案的 **Releases**，下載 `FGO-JP-AutoRoute-Windows-x64.zip`（或直接下載 `FGO-JP-AutoRoute.exe`）。
2. 若下載 ZIP，先解壓縮；將 `FGO-JP-AutoRoute.exe` 放在一般資料夾，不建議放在 `Program Files`。
3. 確認 MuMu 12 已開啟，雙擊 EXE。程式會自動開啟瀏覽器至 `http://127.0.0.1:3789`。
4. 在模擬器設定中連接 MuMu ADB。若自動找不到 `adb.exe`，請填入 MuMu 12 安裝目錄內的 ADB 完整路徑。

EXE 會將設定、任務進度、日誌與你自行擷取的模板儲存在 `%LOCALAPPDATA%\FGO-JP-AutoRoute`，不會寫入 EXE 暫存解壓目錄。更新 EXE 不會刪除這些資料。建議更新前備份該資料夾。

首次啟動可能需要數秒解壓內嵌元件；Windows SmartScreen 也可能對未簽章的個人開源 EXE 顯示警告。請只從你信任的 GitHub Release 下載。

## 開發者：本機編譯 EXE

開發者可在 Windows 11 安裝 Python 3.11+ 後執行 `build_exe.bat`；一般使用者不需要執行這個檔案。推送到 `main`／`master`、推送 `v*` 標籤，或在 Actions 手動執行 `Build Windows EXE and release packages` 工作流程，GitHub Actions 會在 Windows runner 自動測試並編譯 EXE。一般分支推送會產生可下載的 Actions Artifact；推送 `v*` 標籤則會建立正式 GitHub Release。

## 已實作功能

| 功能 | 狀態 |
| --- | --- |
| 類 ALAS 深色瀏覽器控制介面 | ✅ 已做 |
| MuMu 12 ADB 本機連線（自動掃描常用埠） | ✅ 已做，待使用者電腦實測 |
| 擷取遊戲畫面與滑鼠框選按鈕模板 | ✅ 已做 |
| 辨識模板 → 點擊／滑動／等待 | ✅ 已做 |
| 主畫面 → 章節 → 關卡的自訂視覺路線 | ✅ 引擎已做，**每個畫面需自行擷取** |
| 一次勝利計數、重刷指定次數 | ✅ 已做 |
| 辨識「已通關」標記而自動結束重刷 | ✅ 已做，需提供各關的通關標記模板 |
| 下一個關卡自動推進 | ✅ 已做，需事先配置下一關的畫面路線 |
| 倫敦第六節五格進行度辨識 | ✅ v0.2.0 範例已做，依使用者截圖校準；仍需實機逐格驗證 |
| 倫敦路線模板導引與即時進度測試 | ✅ v0.2.0 已做 |
| 基礎戰鬥 Attack 與三張卡自動選擇 | ✅ 範例規則已做，**請校準日版座標和戰術** |
| 排程（每週日期＋時分） | ✅ 已做，程式保持開啟才生效 |
| 暫停、續跑、停止、通關進度儲存、錯誤日誌 | ✅ 已做 |
| 所有日本主線關卡零設定全自動解題／決策 | ❌ 尚未實作 |
| 自動找出任意劇情關卡的完整戰鬥策略 | ❌ 尚未實作 |
| 召喚抽卡、購買道具或付費恢復體力 | ❌ 不提供 |

## 原始碼開發模式（一般使用者不需要）

以下方式只供想修改 Python 原始碼的開發者使用；一般使用者請下載上方 Releases 的 EXE。

1. 安裝 [Python 3.11 或更新版本](https://www.python.org/downloads/windows/)（建議勾選 **Add Python to PATH**）。
2. 啟動 **MuMu 模擬器 12**，打開日版 FGO，畫面建議固定 **16:9 橫向**。
3. 解壓縮原始碼 ZIP。
4. **先按兩下 `install.bat`**：安裝 Flask、OpenCV、NumPy 至專案專用的 `.venv`。
5. **再按兩下 `start.bat`**：瀏覽器開啟 **http://127.0.0.1:3789**。
6. 在「模擬器設定」填寫 ADB 位址後按 **連線 MuMu**。

ADB 推薦先試 `127.0.0.1:16384`；若失敗請用 `auto` 掃描。官方 MuMu 開發手冊也列出部分版本使用 `127.0.0.1:7555` 的情況，因此不能認定所有 MuMu 都用同一埠。[MuMu 官方 ADB 說明](https://www.mumuplayer.com/tw/help/win/developers-essentials-manual.html)

如果找不到 `adb.exe`，可到 [Google 官方 Android SDK Platform Tools](https://developer.android.com/tools/releases/platform-tools) 下載，解壓縮後將路徑填入 ADB 設定，例如 `C:\Android\platform-tools\adb.exe`。

**一般使用者不需要安裝 Python**：請使用 v0.3.0 之後 GitHub Actions 編譯的單檔 Windows EXE。只有要從原始碼執行或自行編譯時才需要 Python。

## 自訂其他日版 FGO 路線

1. 先在 MuMu 進入主畫面，在 **「畫面模板擷取」→「取得畫面」**，拖曳框住「主線／Story」入口圖示，儲存為 `story_button`。
2. 到第一部的選擇畫面，框選章節入口，存為 `part_one`。
3. 到要刷的關卡節點，存為 `quest_node`（其他關卡建議命名 `quest_fuyuki_01` 等）。
4. 到助戰選擇畫面截 `support_first`；到開始前截 `battle_start`；戰鬥中截 `attack_button`。
5. 戰鬥勝利後，截取**只會在一場勝利結算後顯示的固定標記**，命名 `quest_clear`；如有下一頁按鈕，截 `result_next`。
6. 如希望系統自行判定「這個故事關卡究竟還要刷幾次」，到地圖上截取**該節完成後才會出現的、專屬於該節的通關圖示**，例如 `fuyuki_01_cleared`。建議截入小部分獨特的關卡標題或節點邊框，避免匹配其他已通關的節點。
7. 到 **「章節／關卡任務」** 設定：
   - **固定次數**：直接填「需要通關次數」，例如 3 次。每次戰鬥辨識到 `quest_clear` 計 1 次，滿 3 次推下一關。
   - **辨識通關標記**：選「辨識通關標記」，填 `fuyuki_01_cleared` 和最多嘗試次數。每次結算後回地圖檢查，找到才推下一關；超過上限就停止，不會無限刷。
   - 「進入關卡步驟」每步都是 **等待模板出現 → 點擊該模板中心**。按地圖狀態調整，可標記 `optional: true`。
   - 「結算後步驟」負責讓遊戲從獎勵頁回到章節地圖，若要翻多頁，加入多個 `result_next` 步驟。
8. 到 **「戰鬥規則」** 確認 Attack、指令卡的座標是否符合日版 UI。特殊戰鬥通常需要新增技能、寶具、劇情提示等畫面規則。
9. 回儀表板，保持勾選「安全預檢」按開始，先檢查圖片是否齊全。通過後取消勾選，**先選一關測試**，確認正常，再開啟多關與排程。

### 一個導航動作的寫法

「進入關卡步驟」及「結算後步驟」內的 JSON 例子：

```json
[
  {"template": "story_button", "timeout": 20, "optional": true},
  {"template": "part_one", "timeout": 20, "optional": true},
  {"template": "quest_fuyuki_01", "timeout": 30, "optional": false}
]
```

**補充：** 若在地圖上原本就看不到 `story_button`，設 `optional: true` 會在逾時後略過；但每一個選用步驟都要等待，建議在不同路線設不同進入策略，避免浪費時間。

### 戰鬥規則示例

```json
[
  {"type": "tap_match"},
  {"type": "wait", "seconds": 1.2},
  {"type": "tap", "x": 0.15, "y": 0.75},
  {"type": "tap", "x": 0.35, "y": 0.75},
  {"type": "tap", "x": 0.55, "y": 0.75}
]
```

`x`／`y` 是 **0 到 1 的相對座標**，0.5 表示螢幕中心。每一個操作會保留短暫停頓，避免操作過快。範例未做「強度最高指令卡」或「指揮技能」策略優化，不能保證打贏所有主線。

## 排程

「自動排程」→ 新增排程 → 設定名稱、HH:MM、執行的路線、星期一～日 → 儲存。**Windows 時區**即排程時區，程式保持開啟才會啟動。不要讓 Windows 自動睡眠或完全關閉模擬器。預設安全預檢為開啟，若要允許排程實際點擊，需在「模擬器設定」關閉預設安全預檢並儲存。

## GitHub 上傳／後續更新

由於需要在你的帳號建立 GitHub 儲存庫，最容易方式是：

1. 開啟 [github.com/new](https://github.com/new)，登入後建立 **`FGO-JP-AutoRoute`**，可以選 Private 或 Public；**先不要新增 README 或 License**（本專案已有）。
2. 安裝 [GitHub Desktop](https://desktop.github.com/)，選 **File → Add Local Repository**，指向解壓縮後的 `FGO-JP-AutoRoute` 資料夾；若尚未有 `.git`，選 **Create a Repository**。
3. 在 GitHub Desktop 按 **Publish Repository**，將專案推上去。
4. 日後在 GitHub 網頁開啟程式碼，點鉛筆圖示編輯、按 **Commit changes**；本機請用 GitHub Desktop 的 **Fetch origin / Pull origin** 更新，或在以 Git clone 取得的資料夾執行 `update.bat`。
5. GitHub Actions 的 `Python checks` 會在推送程式碼時執行測試；推送至 `main`／`master` 時也會自動編譯 EXE 並提供 Actions Artifact。建立 `v0.3.0` 等 `v*` Tag 後，`Build Windows EXE and release packages` 會另外建立正式 GitHub Release。

**重要：** `.gitignore` 已排除本機 `config/*.json` 和 `templates/*.png`，避免將個人設定與自己擷取的遊戲畫面意外上傳。GitHub 原始碼的設定範例放在 `fgoauto/storage.py`。如果要在不同電腦之間同步關卡設定，需要額外備份或安全移轉這些檔案。

## 安全與限制

- 僅對 `127.0.0.1` 本機提供網頁 UI，不開放網際網路連入。
- 只允許對本機 `127.0.0.1` 的 MuMu ADB 連線，不使用 Root、不讀取遊戲記憶體、不修改遊戲資料或封包。
- 不會自動購買道具、恢復 AP、進行任何付費行為。
- 找不到畫面 90 秒、戰鬥逾時、達到動態刷關上限，都會安全停止並留下錯誤訊息。
- 使用遊戲自動化可能涉及遊戲服務條款及帳號風險；請自行確認條款。
- 所有畫面辨識都可能發生誤判；**不建議完全無人監控長時間執行**，尤其是第一次設定或主線特殊機制。
- `Fate/Grand Order`、`MuMu`、`AzurLaneAutoScript` 等名稱屬於各自的擁有者，本專案與這些官方組織均無關聯。

## 專案目錄

```
FGO-JP-AutoRoute/
├── app.py                    # 本機 Flask HTTP API
├── fgoauto/
│   ├── device.py             # MuMu ADB
│   ├── vision.py             # OpenCV 圖片比對與倫敦五格進度辨識
│   ├── profiles.py           # 倫敦第六節範例路線與模板清單
│   ├── engine.py             # 自動推圖／勝利計數／排程
│   └── storage.py            # JSON 設定與儲存
├── web/                       # ALAS 風格儀表板
├── config/                    # 初次執行時自動建立本機設定
├── templates/                 # 使用者自行擷取的日版 FGO 截圖
├── tests/                     # 自動化測試
├── install.bat                # 初次安裝
├── start.bat                  # 啟動
├── update.bat                 # Git 專案更新
└── .github/workflows/         # GitHub Actions 測試與打包
```

MIT 授權。這是方便擴充與持續改版的基礎專案，不保證任何特定日版 FGO 關卡的即裝即用性。

---

## v0.2.0：依照 22 張日版 FGO 截圖建立倫敦第六節範例

這次更新以使用者提供的 22 張 1280×720 日版畫面作為流程參考，加入 **第四特異點「死界魔霧都市 ロンドン」第六節「ロンドン・ナイト」** 的設定範例。為避免散布遊戲畫面素材，專案只包含文字設定、相對座標及辨識演算法，**不會把遊戲截圖或截圖裁片放進 ZIP／GitHub**。

### 新增內容

- 倫敦第六節路線範例：主畫面章節清單 → 倫敦地圖 NEXT 節點 → ロンドン・ナイト → 支援選擇 → 隊伍確認。
- 分開「首次進入」與「再次進入」步驟，讓同一主線任務的多個進行度可以接續執行。
- 劇情 SKIP／確認、Attack、指令卡選擇、羈絆結果頁、Master EXP 勝利判定、戰利品「次へ」的規則範例。
- 五格進行度偵測：依你提供的任務清單畫面，讀取「クエスト進行度」右側五個箭頭的藍色位置。截圖中未進行時是 0，完成第一段後第一格變藍，辨識器會回報 1/5。
- UI 新增倫敦模板清單、模板名稱快速填入、進行度即時測試。
- 戰鬥 Attack 與指令卡選擇拆成兩個畫面狀態，不再在 Attack 點擊後盲目連點卡牌座標。

### 套用倫敦範例

1. 解壓縮後執行 `install.bat`、`start.bat`。
2. 在「章節／關卡任務」按 **載入倫敦第六節範例**。
3. 先在 MuMu 進入 FGO 終端主畫面，關閉登入獎勵、公告等彈窗。
4. 到「畫面模板擷取」，依照「倫敦第六節模板清單」逐一切換遊戲畫面，按「取得畫面」並框選對應區域。必要模板需全部擷取；`dialogue_next` 是選用模板。
5. 先在倫敦第六節任務清單畫面擷取 `london_quest_row`，再按 **測試進行度辨識**。你提供的兩張任務清單截圖應分別回報 0/5 和 1/5。
6. 在儀表板執行安全預檢。預檢通過後，第一次正式測試請全程看著模擬器；不要直接設定無人值守排程。

### 倫敦進行度偵測的已知限制

- 目前五格箭頭的位置是依 1280×720 截圖校準；請固定 MuMu 的橫向解析度與遊戲 UI 縮放。程式會將 ADB 截圖縮放至 1280×720。
- 目前可由你提供的畫面驗證「0 格」與「第 1 格亮藍」。第 2～5 格及最終 CLEAR 狀態尚未取得實機樣本；正式長時間執行前，應先逐格測試並核對遊戲畫面。
- 範例暫以五格作為目標。若後續畫面顯示箭頭是「目前進行中的步驟」而非「已完成步驟」，或第五格後還需額外戰鬥，需依後續截圖調整 `progress_target`。
- 勝利判定使用 Master EXP 頁的「獲得EXP」標記，而不是單獨使用 RESULT 標題，以降低把敗北結算誤認為勝利的機率。
- 指令卡範例目前選前三張，並非高效率或萬用戰術；遇到特殊敵人、需要指定寶具／技能的戰鬥，請先停用自動化並手動處理，或新增對應規則。

### 新版路線步驟格式

首次進入與再次進入可以分開設定。`scroll_until` 會在指定畫面找不到章節模板時，依設定滑動最多 N 次；`template` 等待並點擊，`wait_template` 只等待不點擊。

```json
[
  {"type":"scroll_until","template":"london_chapter_tile","max_swipes":5,
   "x1":0.78,"y1":0.80,"x2":0.78,"y2":0.32,"duration_ms":450},
  {"type":"template","template":"london_chapter_tile","timeout":12},
  {"type":"template","template":"london_next_node","timeout":30}
]
```

五格進行度設定位於關卡欄位：`mode = progress_arrows`、`progress_target = 5`、`progress_anchor_template = london_quest_row`。每次勝利後，程式會完成結算流程、等待任務列重新出現、讀取藍色箭頭位置；如果進度沒有增加或無法確認任務列，會停止而不是無限重刷。


## v0.3.0：Windows 單檔 EXE

- 新增 GitHub Actions Windows x64 編譯工作流程，輸出單檔 `FGO-JP-AutoRoute.exe`。
- 使用者不需要安裝 Python；雙擊 EXE 後自動開啟本機 WebUI。
- PyInstaller 將 Flask、OpenCV、NumPy 與 `web/` 靜態資源封裝。
- 可寫入的設定、辨識模板及日誌移至 `%LOCALAPPDATA%\FGO-JP-AutoRoute`，避免 one-file EXE 暫存目錄唯讀或每次重啟遺失。
- GitHub Release 同時提供 EXE、Windows x64 ZIP 與原始碼 ZIP。
- 此版本為 EXE 封裝與啟動方式更新；FGO 畫面辨識與戰鬥邏輯仍需在 MuMu 12 實機校準。
