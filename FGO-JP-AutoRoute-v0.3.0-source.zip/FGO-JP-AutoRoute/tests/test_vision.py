import cv2
import numpy as np

from fgoauto import vision


def test_template_matching(tmp_path, monkeypatch):
    frame = np.zeros((720, 1280, 3), dtype=np.uint8)
    patch = np.random.default_rng(42).integers(0, 256, (40, 80, 3), dtype=np.uint8)
    frame[200:240, 410:490] = patch
    path = tmp_path / 'test.png'
    cv2.imwrite(str(path), patch)
    monkeypatch.setattr(vision, 'TEMPLATES', tmp_path)
    hit = vision.match(frame, 'test', threshold=0.9)
    assert hit is not None
    assert hit.score > 0.98
    assert abs(hit.x - 450 / 1280) < 0.002
    assert abs(hit.y - 220 / 720) < 0.002


def test_no_match_without_image(tmp_path, monkeypatch):
    monkeypatch.setattr(vision, 'TEMPLATES', tmp_path)
    frame = np.zeros((720, 1280, 3), dtype=np.uint8)
    assert vision.match(frame, 'missing') is None


def test_london_progress_chevron_detection():
    frame = np.zeros((720, 1280, 3), dtype=np.uint8)
    # No active chevron: all five progress indicators are grey.
    result = vision.detect_london_progress(frame)
    assert result['progress'] == 0
    assert result['active_slots'] == []

    # The first active marker is a bright cyan/blue chevron in slot one.
    # A filled polygon approximates the marker's blue interior.
    pts = np.array([[904, 197], [918, 210], [904, 222], [916, 222],
                    [934, 210], [916, 194]], dtype=np.int32)
    cv2.fillPoly(frame, [pts], (255, 180, 55))  # BGR bright blue
    result = vision.detect_london_progress(frame)
    assert result['progress'] == 1
    assert result['active_slots'] == [1]
