from fgoauto.profiles import LONDON_GUIDE, LONDON_RULES, london_job


def test_london_profile_uses_five_step_progress():
    job = london_job()
    stage = job['stages'][0]
    assert job['id'] == 'jp-london-4th-section-06'
    assert stage['mode'] == 'progress_arrows'
    assert stage['progress_target'] == 5
    assert stage['progress_anchor_template'] == 'london_quest_row'
    assert stage['entry'] and stage['repeat_entry'] and stage['post']
    assert stage['win_template'] == 'victory_exp'


def test_london_profile_template_guide_is_complete():
    names = {item['name'] for item in LONDON_GUIDE}
    assert {'london_chapter_tile', 'london_next_node', 'london_quest_row',
            'support_guest', 'party_start', 'story_skip', 'skip_confirm_yes',
            'attack_button', 'card_select_state', 'result_continue',
            'victory_exp', 'loot_next'} <= names
    assert all(name.isascii() for name in names)
    assert all('template' in rule and 'steps' in rule for rule in LONDON_RULES)
