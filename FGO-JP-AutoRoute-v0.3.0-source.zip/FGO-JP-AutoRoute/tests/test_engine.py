from fgoauto import engine
from fgoauto.storage import safe_template_name


def test_template_name_validation():
    assert safe_template_name('quest_01') == 'quest_01'
    for invalid in ('../secret', 'name.png', '', '中日文'):
        try:
            safe_template_name(invalid)
            assert False, invalid
        except ValueError:
            pass


def test_scheduler_weekday_mapping():
    import datetime
    assert datetime.date(2026, 11, 13).weekday() == 4


def test_progress_count_and_next_stage(monkeypatch):
    db = {}
    def fake_read(k):
        return db.get(k, {'settings': {'safe_mode': False}, 'progress': {}}.get(k, {}))
    def fake_write(k, v):
        import copy
        db[k] = copy.deepcopy(v)
    monkeypatch.setattr(engine, 'read', fake_read)
    monkeypatch.setattr(engine, 'write', fake_write)
    bot = engine.Automation()
    monkeypatch.setattr(bot.device, 'connect', lambda: None)
    navigated = []
    fights = []
    monkeypatch.setattr(bot, '_navigation', lambda steps, label: navigated.append(label))
    monkeypatch.setattr(bot, '_fight', lambda stage: fights.append(stage['id']))
    job = {'id': 'test', 'name': 'demo', 'stages': [
        {'id': 'a', 'name': 'one', 'repeat': 3, 'entry': [], 'post': []},
        {'id': 'b', 'name': 'two', 'repeat': 2, 'entry': [], 'post': []}
    ]}
    bot._run(job, safe_mode=False)
    assert bot.error is None
    assert fights == ['a', 'a', 'a', 'b', 'b']
    assert db['progress']['test']['a'] == 3
    assert db['progress']['test']['b'] == 2
    assert len(navigated) == 10
    fights.clear()
    bot._run(job, safe_mode=False)
    assert fights == []


def test_dynamic_clear_advances_until_marker(monkeypatch):
    db = {'progress': {}}
    monkeypatch.setattr(engine, 'read', lambda k: db.get(k, {'settings': {'safe_mode': False}}))
    monkeypatch.setattr(engine, 'write', lambda k, v: db.__setitem__(k, v))
    bot = engine.Automation()
    monkeypatch.setattr(bot.device, 'connect', lambda: None)
    checks = iter([False, True])
    monkeypatch.setattr(bot, '_clear_detected', lambda stage, seconds=4: next(checks))
    monkeypatch.setattr(bot, '_navigation', lambda steps, label: None)
    fights = []
    monkeypatch.setattr(bot, '_fight', lambda stage: fights.append(stage['id']))
    job = {'id': 'dynamic', 'stages': [
        {'id': 'x', 'name': 'x', 'mode': 'until_clear', 'max_runs': 10, 'entry': [], 'post': []}
    ]}
    bot._run(job, safe_mode=False)
    assert bot.error is None
    assert len(fights) == 2
    assert db['progress']['dynamic']['x__done'] is True


def test_progress_arrows_advances_to_target(monkeypatch):
    db = {'progress': {}}
    monkeypatch.setattr(engine, 'read', lambda k: db.get(k, {'settings': {'safe_mode': False}}))
    monkeypatch.setattr(engine, 'write', lambda k, v: db.__setitem__(k, v))
    bot = engine.Automation()
    monkeypatch.setattr(bot.device, 'connect', lambda: None)
    navigation = []
    fights = []
    monkeypatch.setattr(bot, '_navigation', lambda steps, label: navigation.append(label))
    monkeypatch.setattr(bot, '_fight', lambda stage: fights.append(stage['id']))
    progress_values = iter([1, 2, 3])
    monkeypatch.setattr(bot, '_read_progress_arrows', lambda stage: {'progress': next(progress_values), 'target_slots': 5, 'active_slots': []})
    job = {'id': 'london', 'stages': [{
        'id': 'section6', 'name': 'London 6', 'mode': 'progress_arrows',
        'progress_target': 3, 'max_runs': 5, 'entry': ['first'],
        'repeat_entry': ['repeat'], 'post': ['post'],
    }]}
    bot._run(job, safe_mode=False)
    assert bot.error is None
    assert fights == ['section6', 'section6', 'section6']
    assert navigation == ['首次進入關卡', '戰鬥結算', '再次進入同一進行度任務',
                          '戰鬥結算', '再次進入同一進行度任務', '戰鬥結算']
    assert db['progress']['london']['section6__progress'] == 3
    assert db['progress']['london']['section6__done'] is True


def test_progress_arrows_stops_when_marker_does_not_advance(monkeypatch):
    db = {'progress': {}}
    monkeypatch.setattr(engine, 'read', lambda k: db.get(k, {'settings': {'safe_mode': False}}))
    monkeypatch.setattr(engine, 'write', lambda k, v: db.__setitem__(k, v))
    bot = engine.Automation()
    monkeypatch.setattr(bot.device, 'connect', lambda: None)
    monkeypatch.setattr(bot, '_navigation', lambda steps, label: None)
    monkeypatch.setattr(bot, '_fight', lambda stage: None)
    monkeypatch.setattr(bot, '_read_progress_arrows', lambda stage: {'progress': 0, 'target_slots': 5, 'active_slots': []})
    job = {'id': 'london', 'stages': [{
        'id': 'section6', 'mode': 'progress_arrows', 'progress_target': 5,
        'max_runs': 5, 'entry': [], 'post': [],
    }]}
    bot._run(job, safe_mode=False)
    assert '進行度沒有增加' in bot.error
